Product: Da Vinci Tank, September 2014

Designer: Zombie Cat, http://zombie-cat.org/

Support:  http://forums.obrary.com/category/da-vinci-tank

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary - democratized product design

Description:
This model is made using wood dowels and 5mm plywood.